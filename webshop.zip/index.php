<?php
session_start();
error_reporting(0);
require_once("system/a_func.php");

if (isset($_SESSION['id'])) {
    $q1 = dd_q("SELECT * FROM users WHERE id = ? LIMIT 1", [$_SESSION['id']]);
    if ($q1 && $q1->rowCount() == 1) {
        $user = $q1->fetch(PDO::FETCH_ASSOC);
    } else {
        session_destroy();
        unset($_SESSION['id']);
        $_GET['page'] = "login";
    }
}

// ---------- helpers ----------
function safe_hex($c, $fallback)
{
    $c = trim((string) $c);
    return preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $c) ? $c : $fallback;
}
function hex_to_rgb($hex)
{
    $hex = str_replace("#", "", $hex);
    if (strlen($hex) == 3) {
        $r = hexdec(str_repeat(substr($hex, 0, 1), 2));
        $g = hexdec(str_repeat(substr($hex, 1, 1), 2));
        $b = hexdec(str_repeat(substr($hex, 2, 1), 2));
    } else {
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
    }
    return "$r, $g, $b";
}

$color_main = safe_hex($config['main_color'] ?? '', '#00c9ff');
$color_sec = safe_hex($config['sec_color'] ?? '', '#00b4e6');
$theme_default = (($config['theme_mode'] ?? 'light') == 'dark') ? 'dark' : 'light';

// background image (set from backend > carousel_manage)
$bg_image = trim((string) ($config['bg_image'] ?? ''));
if ($bg_image !== '' && !preg_match('#^(https?://|assets/uploads/)#i', $bg_image)) {
    $bg_image = '';
}
$bg_image_css = str_replace(['"', "'", "\\", "\n", "\r", "(", ")"], '', $bg_image);
$bg_overlay = max(0, min(90, intval($config['bg_overlay'] ?? 35)));

$page = $_GET['page'] ?? '';
$is_admin = (isset($_SESSION['id']) && isset($user) && $user["rank"] == "1");
$is_landing = ($page == "" || $page == "landing");
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="<?= htmlspecialchars($config['name']) ?> | Homepage">
    <meta property="og:type" content="website">
    <meta property="og:image" content="<?= htmlspecialchars($config['logo']) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($config['des']) ?>">
    <title><?= htmlspecialchars($config['name']) ?></title>
    <link rel="shortcut icon" href="<?= htmlspecialchars($config['logo']) ?>" type="image/png" sizes="16x16">
    <link rel="stylesheet" href="system/css/second.css?v=<?= @filemtime(__DIR__ . '/system/css/second.css') ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <link href="https://kit-pro.fontawesome.com/releases/v6.2.0/css/pro.min.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@600&family=Kanit&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="system/css/option.css?v=<?= @filemtime(__DIR__ . '/system/css/option.css') ?>">
    <style>
        :root {
            --xez-primary: <?= $color_main ?>;
            --xez-primary-rgb: <?= hex_to_rgb($color_main) ?>;
            --xez-secondary: <?= $color_sec ?>;
            /* names used by older backend pages */
            --main: <?= $color_main ?>;
            --sub: <?= $color_sec ?>;
        }

        <?php if ($bg_image_css !== ''): ?>
        /* site background image */
        #site-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: url("<?= $bg_image_css ?>") center / cover no-repeat;
        }

        #site-bg::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, <?= $bg_overlay / 100 ?>);
        }

        .landing-hero {
            background: linear-gradient(rgba(10, 10, 21, .72), rgba(26, 10, 37, .85)), url("<?= $bg_image_css ?>") center / cover no-repeat !important;
        }
        <?php endif; ?>

        /* legacy helper classes still used in some backend pages */
        .text-main { color: var(--xez-primary) !important; }
        .bg-main { background-color: var(--xez-primary) !important; }
        .border-main { border-color: var(--xez-primary) !important; }
        .m-cent { margin-left: auto; margin-right: auto; }

        /* theme toggle button */
        .theme-toggle-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 1px solid var(--border-main);
            background: var(--bg-card);
            color: var(--text-heading);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all .25s ease;
        }

        .theme-toggle-btn:hover {
            border-color: var(--xez-primary);
            color: var(--xez-primary);
            transform: rotate(15deg);
        }
    </style>
</head>

<body class="theme-<?= $theme_default ?>">
    <script>
        // remember the visitor's light/dark choice
        (function () {
            try {
                var t = localStorage.getItem('shop_theme');
                if (t === 'dark' || t === 'light') {
                    document.body.classList.remove('theme-light', 'theme-dark');
                    document.body.classList.add('theme-' + t);
                }
            } catch (e) { }
        })();
    </script>
    <?php if ($bg_image_css !== ''): ?>
        <div id="site-bg"></div>
    <?php endif; ?>

    <!-- Preloader -->
    <div id="preloader">
        <div class="loader-content">
            <div class="loader-logo">
                <img src="<?= htmlspecialchars($config['logo']) ?>" alt="Logo">
            </div>
            <div class="loader-bar">
                <div class="loader-progress"></div>
            </div>
            <p class="loader-text mt-3 fw-bold"><?= htmlspecialchars($config['name']) ?></p>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg sticky-top main-navbar">
        <div class="container container-sm">
            <a class="navbar-brand d-flex align-items-center" href="/?page=home">
                <img src="<?= htmlspecialchars($config['logo']) ?>" height="40px" width="auto" class="me-2">
                <span class="navbar-text-brand fw-bold"><?= htmlspecialchars($config['name']) ?></span>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=home"><i class="fa-solid fa-house me-1"></i> หน้าหลัก</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=shop"><i class="fa-solid fa-shopping-basket me-1"></i> ร้านค้า</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=topup"><i class="fa-solid fa-coins me-1"></i> เติมเงิน</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=how"><i class="fa-solid fa-circle-question me-1"></i> วิธีใช้</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="<?= htmlspecialchars($config['contact']) ?>"><i class="fa-solid fa-phone me-1"></i> ติดต่อ</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <button type="button" class="theme-toggle-btn me-2" id="themeToggle" title="สลับโหมดสว่าง / มืด" aria-label="สลับโหมดสว่าง / มืด">
                        <i class="fa-solid fa-moon" id="themeToggleIcon"></i>
                    </button>
                    <div class="nav-separator mx-2 d-none d-lg-block"></div>
                    <?php if (!isset($_SESSION['id'])): ?>
                        <a href="?page=login" class="nav-link-xez nav-link fw-bold me-3"><i class="fa-solid fa-sign-in me-1"></i> เข้าสู่ระบบ</a>
                        <a href="?page=register" class="btn btn-navbar-register"><i class="fa-solid fa-user-plus me-1"></i> สมัครสมาชิก</a>
                    <?php else: ?>
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-circle-user me-1"></i>
                                <?= htmlspecialchars($user["username"]) ?>
                                <span class="ms-1 text-xez-primary">(฿<?= number_format($user['point']) ?>)</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 p-2">
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile&subpage=buyhis"><i class="fa-solid fa-clock-rotate-left me-2"></i> ประวัติการสั่งซื้อ</a></li>
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile&subpage=topuphis"><i class="fa-solid fa-coins me-2"></i> ประวัติเติมเงิน</a></li>
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile"><i class="fa-solid fa-user me-2"></i> โปรไฟล์</a></li>
                                <?php if ($is_admin): ?>
                                    <li><a class="dropdown-item text-primary rounded-3 mb-1" href="?page=backend"><i class="fa-solid fa-shield-halved me-2"></i> จัดการหลังร้าน</a></li>
                                <?php endif; ?>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item text-danger rounded-3" href="?page=logout"><i class="fa-solid fa-sign-out me-2"></i> ออกจากระบบ</a></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php
    $backend_pages = ['backend', 'user_edit', 'category_manage', 'product_manage', 'code_manage', 'backend_buy_history', 'backend_topup_history', 'website', 'carousel_manage', 'recom_manage', 'crecom_manage', 'apibyshop', 'apibyshop_his', 'slip_manage'];
    $need_login = ['profile', 'topup', 'slip', 'redeem'];

    if ($is_landing) {
        require_once('page/landing.php');
    } elseif ($page == "home") {
        require_once('page/simple.php');
    } elseif ($page == "login") {
        if (isset($_SESSION['id'])) {
            echo "<script>window.location.href = '?page=home';</script>";
        } else {
            require_once('page/login.php');
        }
    } elseif ($page == "register") {
        if (isset($_SESSION['id'])) {
            echo "<script>window.location.href = '?page=home';</script>";
        } else {
            require_once('page/register.php');
        }
    } elseif ($page == "logout") {
        session_destroy();
        echo "<script>window.location.href = './';</script>";
    } elseif (in_array($page, $need_login) && !isset($_SESSION['id'])) {
        require_once('page/login.php');
    } elseif ($page == "profile") {
        require_once('page/profile.php');
    } elseif ($page == "topup") {
        require_once('page/topup.php');
    } elseif ($page == "slip") {
        require_once('page/slip.php');
    } elseif ($page == "redeem") {
        require_once('page/redeem.php');
    } elseif ($page == "shop") {
        require_once('page/shop.php');
    } elseif ($page == "product" && isset($_GET['id'])) {
        require_once('page/product.php');
    } elseif ($page == "how") {
        require_once('page/how.php');
    } elseif ($is_admin && $page == "stock_manage" && !empty($_GET['id'])) {
        require_once('page/backend/menu_manage.php');
    } elseif ($is_admin && in_array($page, $backend_pages)) {
        require_once('page/backend/menu_manage.php');
    } else {
        require_once('page/simple.php');
    }
    ?>

    <?php if (!$is_landing): ?>
        <!-- Footer -->
        <footer class="site-footer">
            <div class="container">
                <div class="row g-4">
                    <div class="col-lg-5 col-md-12">
                        <div class="footer-brand">
                            <img src="<?= htmlspecialchars($config['logo']) ?>" alt="Logo" class="footer-logo">
                            <h4 class="footer-title"><?= htmlspecialchars($config['name']) ?></h4>
                            <p class="footer-desc"><?= htmlspecialchars($config['des']) ?></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="footer-heading">เมนูหลัก</h5>
                        <ul class="footer-links">
                            <li><a href="?page=home"><i class="fa-solid fa-home me-2"></i>หน้าหลัก</a></li>
                            <li><a href="?page=shop"><i class="fa-solid fa-shopping-bag me-2"></i>ร้านค้า</a></li>
                            <li><a href="?page=topup"><i class="fa-solid fa-wallet me-2"></i>เติมเงิน</a></li>
                            <li><a href="?page=how"><i class="fa-solid fa-circle-question me-2"></i>วิธีใช้</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <h5 class="footer-heading">บัญชีของฉัน</h5>
                        <ul class="footer-links">
                            <?php if (isset($_SESSION['id'])): ?>
                                <li><a href="?page=profile&subpage=buyhis"><i class="fa-solid fa-history me-2"></i>ประวัติซื้อสินค้า</a></li>
                                <li><a href="?page=profile&subpage=topuphis"><i class="fa-solid fa-receipt me-2"></i>ประวัติเติมเงิน</a></li>
                                <li><a href="?page=profile"><i class="fa-solid fa-user me-2"></i>โปรไฟล์</a></li>
                            <?php else: ?>
                                <li><a href="?page=login"><i class="fa-solid fa-sign-in me-2"></i>เข้าสู่ระบบ</a></li>
                                <li><a href="?page=register"><i class="fa-solid fa-user-plus me-2"></i>สมัครสมาชิก</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($config['name']) ?>. All rights reserved.</p>
                <p class="small opacity-75">Icon by Fontawesome &amp; Flaticon</p>
            </div>
        </footer>
        <style>
            .site-footer {
                background: linear-gradient(135deg, var(--xez-primary) 0%, var(--xez-secondary) 100%);
                padding: 50px 0 25px;
                margin-top: 60px;
                color: #fff;
            }

            .footer-brand .footer-logo {
                width: 80px;
                height: 80px;
                object-fit: contain;
                margin-bottom: 15px;
                border-radius: 20px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            }

            .footer-title {
                font-weight: 700;
                color: #fff !important;
                margin-bottom: 10px;
            }

            .footer-desc {
                color: rgba(255, 255, 255, .85);
                font-size: 0.9rem;
                line-height: 1.6;
            }

            .footer-heading {
                color: #fff !important;
                font-weight: 600;
                margin-bottom: 18px;
                font-size: 1rem;
            }

            .footer-links {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .footer-links li {
                margin-bottom: 10px;
            }

            .footer-links a {
                color: rgba(255, 255, 255, .85);
                text-decoration: none;
                font-size: 0.9rem;
                transition: all 0.3s ease;
            }

            .footer-links a:hover {
                color: #fff;
                padding-left: 5px;
            }

            .footer-bottom {
                border-top: 1px solid rgba(255, 255, 255, 0.25);
                margin-top: 35px;
                padding-top: 22px;
                text-align: center;
            }

            .footer-bottom p {
                margin: 5px 0;
                color: rgba(255, 255, 255, .85);
            }
        </style>
    <?php endif; ?>

    <script>
        // scroll-in animations
        AOS.init({ duration: 800, once: true });

        // light / dark toggle
        (function () {
            var btn = document.getElementById('themeToggle');
            var icon = document.getElementById('themeToggleIcon');
            function paint() {
                var dark = document.body.classList.contains('theme-dark');
                if (icon) { icon.className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon'; }
            }
            paint();
            if (btn) {
                btn.addEventListener('click', function () {
                    var dark = document.body.classList.contains('theme-dark');
                    document.body.classList.remove('theme-light', 'theme-dark');
                    document.body.classList.add(dark ? 'theme-light' : 'theme-dark');
                    try { localStorage.setItem('shop_theme', dark ? 'light' : 'dark'); } catch (e) { }
                    paint();
                });
            }
        })();

        // preloader
        (function () {
            var preloader = document.getElementById('preloader');
            var progress = document.querySelector('.loader-progress');
            if (progress) {
                setTimeout(function () { progress.style.width = '30%'; }, 100);
                setTimeout(function () { progress.style.width = '70%'; }, 500);
            }
            function hidePreloader() {
                if (!preloader || preloader.style.display === 'none') return;
                if (progress) progress.style.width = '100%';
                setTimeout(function () {
                    preloader.classList.add('fade-out');
                    setTimeout(function () { preloader.style.display = 'none'; }, 400);
                }, 200);
            }
            window.addEventListener('load', hidePreloader);
            setTimeout(hidePreloader, 2500);
        })();
    </script>
</body>

</html>
