<?php
// Top-up hub: choose a payment method
$sub = $_GET['sub'] ?? '';
if ($sub == 'gift'):
    require_once('page/topup_gift.php');
else:
?>
    <div class="container-sm mt-4">
        <div class="mb-4">
            <h2 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-wallet text-xez-primary me-2"></i> เติมเงิน</h2>
            <p class="text-muted small">หน้าหลัก > เติมเงิน</p>
        </div>
        <div class="row g-4 justify-content-center">
            <div class="col-12 col-md-4">
                <a href="?page=topup&sub=gift" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="rounded-3 p-3 me-3 topup-ico"><i class="fa-solid fa-gift"></i></div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">TrueMoney</h5>
                            <p class="text-muted small mb-1">ซองของขวัญอั่งเปา</p>
                            <span class="badge bg-success-soft text-success small">ปกติ</span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="?page=redeem" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="rounded-3 p-3 me-3 topup-ico"><i class="fa-solid fa-ticket"></i></div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">Redeem</h5>
                            <p class="text-muted small mb-1">กรอกโค้ดแลกพ้อยท์</p>
                            <span class="badge bg-success-soft text-success small">ปกติ</span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-md-4">
                <a href="?page=slip" class="text-decoration-none">
                    <div class="xez-card h-100 d-flex align-items-center p-3">
                        <div class="rounded-3 p-3 me-3 topup-ico"><i class="fa-solid fa-building-columns"></i></div>
                        <div class="flex-grow-1">
                            <h5 class="fw-bold text-dark mb-0">โอนผ่านธนาคาร</h5>
                            <p class="text-muted small mb-1">แนบสลิปการโอนเงิน</p>
                            <span class="badge bg-success-soft text-success small">แนะนำ</span>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <style>
        .topup-ico {
            width: 72px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.9rem;
            color: #fff;
            background: linear-gradient(135deg, var(--xez-primary), var(--xez-secondary));
        }
    </style>
<?php endif; ?>
