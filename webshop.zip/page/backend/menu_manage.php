<?php
$sub = $_GET['page'] ?? 'backend';
function isActive($page, $current)
{
    return $page == $current ? 'active' : '';
}
?>
<div class="container-fluid mt-4 mb-5">
    <div class="container ps-0 pe-0 m-auto">
        <div class="row g-4">
            <div class="col-lg-3">
                <div class="xez-card p-3 admin-sidebar">
                    <div class="p-3 mb-3">
                        <h5 class="fw-bold text-dark mb-1"><i class="fa-solid fa-gears text-xez-primary me-2"></i> ระบบหลังบ้าน</h5>
                        <p class="text-muted small mb-0">Management Console</p>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="?page=backend" class="list-group-item list-group-item-action <?= isActive('backend', $sub) ?>">
                            <i class="fa-solid fa-chart-pie"></i> แดชบอร์ด
                        </a>
                        <a href="?page=website" class="list-group-item list-group-item-action <?= isActive('website', $sub) ?>">
                            <i class="fa-solid fa-browser"></i> ตั้งค่าเว็บไซต์
                        </a>
                        <a href="?page=slip_manage" class="list-group-item list-group-item-action <?= isActive('slip_manage', $sub) ?>">
                            <i class="fa-solid fa-receipt"></i> จัดการเช็คสลิป
                        </a>
                        <hr class="my-2 opacity-10">
                        <a href="?page=user_edit" class="list-group-item list-group-item-action <?= isActive('user_edit', $sub) ?>">
                            <i class="fa-solid fa-users"></i> ผู้ใช้งาน
                        </a>
                        <a href="?page=category_manage" class="list-group-item list-group-item-action <?= isActive('category_manage', $sub) ?>">
                            <i class="fa-solid fa-layer-group"></i> หมวดหมู่
                        </a>
                        <a href="?page=product_manage" class="list-group-item list-group-item-action <?= isActive('product_manage', $sub) ?>">
                            <i class="fa-solid fa-box-open"></i> สินค้า
                        </a>
                        <a href="?page=code_manage" class="list-group-item list-group-item-action <?= isActive('code_manage', $sub) ?>">
                            <i class="fa-solid fa-ticket"></i> โค้ดแลกพ้อยท์
                        </a>
                        <hr class="my-2 opacity-10">
                        <a href="?page=backend_topup_history" class="list-group-item list-group-item-action <?= isActive('backend_topup_history', $sub) ?>">
                            <i class="fa-solid fa-wallet"></i> ประวัติเติมเงิน
                        </a>
                        <a href="?page=backend_buy_history" class="list-group-item list-group-item-action <?= isActive('backend_buy_history', $sub) ?>">
                            <i class="fa-solid fa-shopping-bag"></i> ประวัติสั่งซื้อ
                        </a>
                        <hr class="my-2 opacity-10">
                        <a href="?page=carousel_manage" class="list-group-item list-group-item-action <?= isActive('carousel_manage', $sub) ?>">
                            <i class="fa-solid fa-image"></i> ภาพสไลด์ / รูปพื้นหลัง
                        </a>
                        <a href="?page=recom_manage" class="list-group-item list-group-item-action <?= isActive('recom_manage', $sub) ?>">
                            <i class="fa-solid fa-star"></i> สินค้าแนะนำ
                        </a>
                        <a href="?page=crecom_manage" class="list-group-item list-group-item-action <?= isActive('crecom_manage', $sub) ?>">
                            <i class="fa-solid fa-fire"></i> หมวดหมู่แนะนำ
                        </a>
                        <hr class="my-2 opacity-10">
                        <a href="?page=apibyshop" class="list-group-item list-group-item-action <?= isActive('apibyshop', $sub) ?>">
                            <i class="fa-solid fa-plug"></i> ตั้งค่า byshop
                        </a>
                        <a href="?page=apibyshop_his" class="list-group-item list-group-item-action <?= isActive('apibyshop_his', $sub) ?>">
                            <i class="fa-solid fa-clock-rotate-left"></i> ประวัติสั่งซื้อแอพ
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <?php
                $bp = $_GET['page'] ?? 'backend';
                if ($bp == "backend") {
                    require_once('page/backend/dashboard.php');
                } elseif ($bp == "user_edit") {
                    require_once('page/backend/user_edit.php');
                } elseif ($bp == "category_manage") {
                    require_once('page/backend/category.php');
                } elseif ($bp == "product_manage") {
                    require_once('page/backend/product.php');
                } elseif ($bp == "stock_manage" && !empty($_GET['id'])) {
                    require_once('page/backend/stock.php');
                } elseif ($bp == "code_manage") {
                    require_once('page/backend/code_manage.php');
                } elseif ($bp == "backend_buy_history") {
                    require_once('page/backend/buy_history.php');
                } elseif ($bp == "backend_topup_history") {
                    require_once('page/backend/topup_history.php');
                } elseif ($bp == "website") {
                    require_once('page/backend/website.php');
                } elseif ($bp == "carousel_manage") {
                    require_once('page/backend/carousel_manage.php');
                } elseif ($bp == "recom_manage") {
                    require_once('page/backend/recom_manage.php');
                } elseif ($bp == "crecom_manage") {
                    require_once('page/backend/crecom_manage.php');
                } elseif ($bp == "apibyshop") {
                    require_once('page/backend/apibyshop.php');
                } elseif ($bp == "apibyshop_his") {
                    require_once('page/backend/apibyshop_his.php');
                } elseif ($bp == "slip_manage") {
                    require_once('page/backend/slip_manage.php');
                }
                ?>
            </div>
        </div>
    </div>
</div>
