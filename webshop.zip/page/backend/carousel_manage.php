<?php
$bg_now = $config['bg_image'] ?? '';
$bg_ov  = isset($config['bg_overlay']) ? intval($config['bg_overlay']) : 35;
?>
<div class="container-sm xez-card border mt-5 shadow-sm p-4 mb-4" id="bg_card">
    <center>
        <h1 class="text-dark">&nbsp;<i class="fa-solid fa-panorama"></i>&nbsp;รูปพื้นหลังเว็บไซต์</h1>
        <p class="text-muted mb-0">เปลี่ยนรูปพื้นหลังของทั้งเว็บ อัปโหลดจากเครื่อง หรือวางลิงก์รูปก็ได้</p>
    </center>
    <hr class="mt-3 mb-3 border-secondary">
    <div class="row g-4">
        <div class="col-lg-5">
            <p class="text-secondary mb-1">รูปที่ใช้อยู่ตอนนี้</p>
            <div id="bg_preview" class="rounded border d-flex align-items-center justify-content-center text-muted"
                style="height: 180px; background-size: cover; background-position: center; overflow: hidden; <?php if ($bg_now != '') { echo "background-image: url('" . htmlspecialchars(str_replace(["'", "\\"], '', $bg_now), ENT_QUOTES) . "');"; } ?>">
                <?php if ($bg_now == '') { echo '<span>ยังไม่ได้ตั้งรูปพื้นหลัง</span>'; } ?>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="mb-3">
                <p class="text-secondary mb-1">อัปโหลดรูปจากเครื่อง <small class="text-muted">(JPG / PNG / WEBP / GIF ไม่เกิน 5 MB)</small></p>
                <input type="file" id="bg_file" class="form-control" accept="image/png,image/jpeg,image/webp,image/gif">
            </div>
            <div class="mb-3">
                <p class="text-secondary mb-1">หรือวางลิงก์รูปภาพ</p>
                <input type="text" id="bg_link" class="form-control" placeholder="https://..."
                    value="<?php echo (preg_match('#^https?://#i', $bg_now)) ? htmlspecialchars($bg_now, ENT_QUOTES) : ''; ?>">
            </div>
            <div class="mb-3">
                <p class="text-secondary mb-1">ความมืดของภาพ (ช่วยให้อ่านตัวหนังสือง่ายขึ้น): <b id="bg_ov_label"><?php echo $bg_ov; ?></b>%</p>
                <input type="range" id="bg_overlay" class="form-range" min="0" max="90" step="5" value="<?php echo $bg_ov; ?>">
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <button type="button" class="btn btn-success px-4" id="bg_save"><i class="fa-solid fa-floppy-disk"></i>&nbsp;บันทึกรูปพื้นหลัง</button>
                <button type="button" class="btn btn-outline-danger px-4" id="bg_remove" <?php if ($bg_now == '') { echo 'disabled'; } ?>><i class="fa-solid fa-trash"></i>&nbsp;ลบรูปพื้นหลัง</button>
            </div>
        </div>
    </div>
</div>
<script>
    (function () {
        function bgError(jqXHR) {
            var res = jqXHR.responseJSON;
            Swal.fire({ icon: 'error', title: 'เกิดข้อผิดพลาด', text: res && res.message ? res.message : 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้' });
            $('#bg_save, #bg_remove').prop('disabled', false);
        }
        function bgSend(formData) {
            $('#bg_save, #bg_remove').prop('disabled', true);
            $.ajax({
                type: 'POST',
                url: 'system/backend/bg_update.php',
                data: formData,
                contentType: false,
                processData: false
            }).done(function (res) {
                Swal.fire({ icon: 'success', title: 'สำเร็จ', text: res.message }).then(function () {
                    window.location.reload();
                });
            }).fail(bgError);
        }
        $('#bg_overlay').on('input', function () { $('#bg_ov_label').text(this.value); });
        $('#bg_file').on('change', function () {
            var f = this.files && this.files[0];
            if (!f) { return; }
            var r = new FileReader();
            r.onload = function (e) {
                $('#bg_preview').css('background-image', 'url(' + e.target.result + ')').text('');
            };
            r.readAsDataURL(f);
        });
        $('#bg_save').on('click', function () {
            var fd = new FormData();
            fd.append('overlay', $('#bg_overlay').val());
            var f = $('#bg_file')[0].files[0];
            var link = $.trim($('#bg_link').val());
            if (f) {
                fd.append('mode', 'upload');
                fd.append('file', f);
            } else if (link !== '') {
                fd.append('mode', 'url');
                fd.append('link', link);
            } else {
                fd.append('mode', 'overlay');
            }
            bgSend(fd);
        });
        $('#bg_remove').on('click', function () {
            Swal.fire({
                title: 'ลบรูปพื้นหลัง?',
                text: 'เว็บจะกลับไปใช้พื้นหลังสีปกติ',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'ลบเลย',
                cancelButtonText: 'ยกเลิก'
            }).then(function (r) {
                if (r.isConfirmed) {
                    var fd = new FormData();
                    fd.append('mode', 'remove');
                    bgSend(fd);
                }
            });
        });
    })();
</script>
<div class="container-sm xez-card border border-2 shadow-sm p-4 mb-4" >
    <center>
        <h1 class="text-dark">&nbsp;<i class="fa-duotone fa-image"></i>&nbsp;จัดการภาพสไลด์</h1>
    </center>
    <hr class="mt-1 mb-1 border-secondary" >
    <div class="d-flex justify-content-center">
        <button class="ms-2 me-2 mt-3 mb-0 btn btn-success col-12 col-lg-5 " id="open_insert"> เพิ่มภาพใหม่</button>
    </div>
    <div class="table-responsive mt-3 ">
        <table id="table" class="table mt-2">
            <thead class="table-dark bg-dark ">
                <tr class="">
                    <th class="sorting sorting_asc">id</th>
                    <th > ลิงค์รูปภาพ</th>
                    <th > แก้ไข</th>
                    <th > ลบ</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $get_user = dd_q("SELECT * FROM carousel ORDER BY id DESC");
                    while($row = $get_user->fetch(PDO::FETCH_ASSOC)){
                ?>
                    <tr >
                        <td class="text-dark"><?php echo $row['id'];?></td>
                        <td class="text-dark" ><img src="<?php echo htmlspecialchars($row['link']);?>" width="100" style="max-height:60px;object-fit:cover" onerror="this.style.display='none'"></td>
                        <td ><button class="btn btn-warning text-dark w-100" style="width : 130px!important" onclick="get_detail(<?php echo $row['id'];?>)"><i class="fa-solid fa-pencil"></i>&nbsp;แก้ไข</button></td>
                        <td><button class="btn btn-danger text-white w-100"  style="width : 130px!important" onclick="del('<?php echo intval($row['id']);?>','ภาพสไลด์ #<?php echo intval($row['id']);?>')"><i class="fa-solid fa-trash" ></i> ลบ</button></td>
                    </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>
<div class="modal fade" id="product_insert" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa-duotone fa-pencil"></i>&nbsp;&nbsp;แก้ไขสินค้า</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-lg-10 m-cent ">
                    <div class="mb-2">
                        <div class="mb-2">
                            <p class="text-secondary mb-1">ลิงค์รูปภาพ <span class="text-danger">*</span></p>
                            <input type="text" id="link" class="form-control" value="">
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิดหน้านี้</button>
                <button type="button" class="btn btn-primary ps-4 pe-4" id="insert_btn" data-id="">บันทึก</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="product_detail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa-duotone fa-pencil"></i>&nbsp;&nbsp;แก้ไขสินค้า</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-lg-10 m-cent ">
                    <div class="mb-2">
                        <div class="mb-2">
                            <p class="text-secondary mb-1">จำนวนเงินที่ได้รับ <span class="text-danger">*</span></p>
                            <input type="text" id="upt_link" class="form-control" value="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="save_btn" data-id="">Save changes</button>
            </div>
        </div>
    </div>
</div>
        <script>
            $("#open_insert").click(function(){
                const myModal = new bootstrap.Modal('#product_insert', {
                    keyboard: false
                })
                myModal.show();
            });
            $("#save_btn").click(function(){
                var formData = new FormData();
                formData.append('id'  , $("#save_btn").attr("data-id") );
                formData.append('link'  , $("#upt_link").val());
                $.ajax({
                    type: 'POST',
                    url: 'system/backend/carousel_update.php',
                    data:formData,
                    contentType: false,
                    processData: false,   
                }).done(function(res){
                    result = res;
                    Swal.fire({
                        icon: 'success',
                        title: 'สำเร็จ',
                        text: result.message
                    }).then(function() {
                            window.location = "?page=<?php echo $_GET['page'];?>";
                    });
                }).fail(function(jqXHR){
                    console.log(jqXHR);
                    res = jqXHR.responseJSON;
                    Swal.fire({
                        icon: 'error',
                        title: 'เกิดข้อผิดพลาด',
                        text: res.message
                    })
                    //console.clear();
                });
                // $("#save_btn").attr("data-id") <- id user
            });
            $("#insert_btn").click(function(){
                var formData = new FormData();
                formData.append('link'  , $("#link").val());
                $.ajax({
                    type: 'POST',
                    url: 'system/backend/carousel_insert.php',
                    data:formData,
                    contentType: false,
                    processData: false,   
                }).done(function(res){
                    result = res;
                    Swal.fire({
                        icon: 'success',
                        title: 'สำเร็จ',
                        text: result.message
                    }).then(function() {
                            window.location = "?page=<?php echo $_GET['page'];?>";
                    });
                }).fail(function(jqXHR){
                    console.log(jqXHR);
                    res = jqXHR.responseJSON;
                    Swal.fire({
                        icon: 'error',
                        title: 'เกิดข้อผิดพลาด',
                        text: res.message
                    })
                    //console.clear();
                });
                // $("#save_btn").attr("data-id") <- id user
            });
            function get_detail(id){
                var formData = new FormData();
                formData.append('id'  , id);
                
                $.ajax({
                    type: 'POST',
                    url: 'system/backend/call/carousel_detail.php',
                    data:formData,
                    contentType: false,
                    processData: false,   
                }).done(function(res){
                    console.log(res);
                    $("#upt_link").val(res.link);
                    $("#save_btn").attr("data-id" , id);
                    const myModal = new bootstrap.Modal('#product_detail', {
                        keyboard: false
                    })
                    myModal.show();
                }).fail(function(jqXHR){
                    console.log(jqXHR);
                    res = jqXHR.responseJSON;
                    Swal.fire({
                        icon: 'error',
                        title: 'เกิดข้อผิดพลาด',
                        text: res.message
                    })
                    //console.clear();
                });
                
            }
            function del(id , username){
                Swal.fire({
                    title: 'ยืนยันที่จะลบ?',
                    text: "คุณแน่ใจหรอที่จะลบ   "+username,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'ลบเลย'
                }).then((result) => {
                    if (result.isConfirmed) {
                        var formData = new FormData();
                        formData.append('id'  , id);
                        $.ajax({
                            type: 'POST',
                            url: 'system/backend/carousel_del.php',
                            data:formData,
                            contentType: false,
                            processData: false,   
                        }).done(function(res){
                            result = res;
                            Swal.fire({
                                icon: 'success',
                                title: 'สำเร็จ',
                                text: result.message
                            }).then(function() {
                                    window.location = "?page=<?php echo $_GET['page'];?>";
                            });
                        }).fail(function(jqXHR){
                            console.log(jqXHR);
                            res = jqXHR.responseJSON;
                            Swal.fire({
                                icon: 'error',
                                title: 'เกิดข้อผิดพลาด',
                                text: res.message
                            })
                            //console.clear();
                        });
                    }
                })
                
                
            }
        </script>
        
<script type="text/javascript">
    $(document).ready(function () {
        $('#table').DataTable();
    });
        $("#btn_regis").click(function(e) {
            e.preventDefault();
            var formData = new FormData();
            formData.append('name'  , $("#site_name").val() );
            formData.append('bg'  , $("#site_bg").val() );
            formData.append('phone'  , $("#site_phone").val() );
            formData.append('main_color'  , $("#site_main_color").val() );
            formData.append('logo'  , $("#site_logo").val() );
            formData.append('sec_color'  , $("#site_sec_color").val() );
            formData.append('contact'  , $("#site_contact").val() );
            formData.append('des'  , $("#site_des").val() );
            $('#btn_regis').attr('disabled', 'disabled');
            $.ajax({
                type: 'POST',
                url: 'system/backend/website.php',
                data:formData,
                contentType: false,
                processData: false,   
            }).done(function(res){
                result = res;
                console.log(result);
                Swal.fire({
                    icon: 'success',
                    title: 'สำเร็จ',
                    text: result.message
                }).then(function() {
                        window.location = "?page=<?php echo $_GET['page'];?>";
                });
            }).fail(function(jqXHR){
                console.log(jqXHR);
                res = jqXHR.responseJSON;
                Swal.fire({
                    icon: 'error',
                    title: 'เกิดข้อผิดพลาด',
                    text: res.message
                })
                //console.clear();
                $('#btn_regis').removeAttr('disabled');
            });
        });
</script>