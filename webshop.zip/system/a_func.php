<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db = "catullusshop";
// connect to database
$conn = new PDO("mysql:host=$host;dbname=$db", $db_user, $db_pass);
$conn->exec("set names utf8mb4");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// end connect to database

// function query
function dd_q($str, $arr = [])
{
    global $conn;
    try {
        $exec = $conn->prepare($str);
        $exec->execute($arr);
    } catch (PDOException $e) {
        return false;
    }
    return $exec;
}
// end function query

// function check login
function check_login()
{
    return isset($_SESSION['id']);
}
function checknull($var = [])
{
    foreach ($var as $key => $value) {
        if ($value == "" || empty($value) || !isset($value)) {
            return false;
        }
    }
    return true;
}

$conf['sitekey'] = "6LdmDFkkAAAAAEKni0zQPY4MEtv2nxLodGLEQvVO";
$conf['secretkey'] = "6LdmDFkkAAAAAAFYBGr37VPuRl-L1hfwraFwO5pW";
function base_url()
{
    return "";
}

// ------------------------------------------------------------------
// Auto-upgrade: adds the new columns the first time the site runs, so
// an existing database keeps working without importing anything.
// ------------------------------------------------------------------
function ensure_schema()
{
    global $conn;
    if (!empty($_SESSION['schema_v1'])) {
        return;
    }
    $cols = [
        ['setting', 'bg_image', "ALTER TABLE `setting` ADD COLUMN `bg_image` VARCHAR(500) NOT NULL DEFAULT ''"],
        ['setting', 'bg_overlay', "ALTER TABLE `setting` ADD COLUMN `bg_overlay` INT NOT NULL DEFAULT 35"],
        ['setting', 'theme_mode', "ALTER TABLE `setting` ADD COLUMN `theme_mode` VARCHAR(10) NOT NULL DEFAULT 'light'"],
        ['static', 'c_count', "ALTER TABLE `static` ADD COLUMN `c_count` INT NOT NULL DEFAULT 0"],
        ['static', 'sold_count', "ALTER TABLE `static` ADD COLUMN `sold_count` INT NOT NULL DEFAULT 0"],
    ];
    try {
        foreach ($cols as $c) {
            $chk = $conn->query("SHOW COLUMNS FROM `" . $c[0] . "` LIKE '" . $c[1] . "'");
            if ($chk && $chk->rowCount() == 0) {
                $conn->exec($c[2]);
            }
        }
        $_SESSION['schema_v1'] = 1;
    } catch (Exception $e) {
        // ignore: the site still works with the old columns
    }
}
ensure_schema();

$get_setting = dd_q("SELECT * FROM setting");
$config = $get_setting->fetch(PDO::FETCH_ASSOC);

$byshop = dd_q("SELECT * FROM byshop")->fetch(PDO::FETCH_ASSOC);
$byshop_status = $byshop["status"];
$byshop_key = $byshop["apikey"];
$byshop_cost = $byshop["cost"];

if (isset($_SESSION['id'])) {
    $q1 = dd_q("SELECT * FROM users WHERE id = ? LIMIT 1", [$_SESSION['id']]);
    $user = $q1->fetch(PDO::FETCH_ASSOC);
}
