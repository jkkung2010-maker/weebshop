<?php
// Change / remove the site background image (admin only)
require_once '../a_func.php';

header('Content-Type: application/json; charset=utf-8;');

function bg_return($status, $message, $extra = [])
{
    http_response_code($status ? 200 : 400);
    die(json_encode(array_merge(['message' => $message], $extra), JSON_UNESCAPED_UNICODE));
}

function bg_delete_old_upload($path)
{
    // only ever delete files we uploaded ourselves
    if (preg_match('#^assets/uploads/bg_[a-f0-9]{16}\.(jpg|png|webp|gif)$#', (string) $path)) {
        $full = dirname(__DIR__, 2) . '/' . $path;
        if (is_file($full)) {
            @unlink($full);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    bg_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}
if (!isset($_SESSION['id'])) {
    bg_return(false, "เข้าสู่ระบบก่อน");
}
$admin = dd_q('SELECT id FROM users WHERE id = ? AND rank = 1', [$_SESSION['id']]);
if (!$admin || $admin->rowCount() < 1) {
    bg_return(false, "คุณไม่มีสิทธิ์ทำรายการนี้");
}

$current = dd_q("SELECT bg_image FROM setting LIMIT 1");
$current = $current ? $current->fetch(PDO::FETCH_ASSOC) : false;
if (!$current) {
    bg_return(false, "อ่านการตั้งค่าเว็บไม่ได้ (ลองรีเฟรชหน้าเว็บ 1 ครั้งเพื่ออัปเกรดฐานข้อมูล)");
}
$old = $current['bg_image'] ?? '';

$mode = $_POST['mode'] ?? '';
$overlay = isset($_POST['overlay']) ? intval($_POST['overlay']) : 35;
$overlay = max(0, min(90, $overlay));

if ($mode === 'remove') {
    $ok = dd_q("UPDATE setting SET bg_image = ''");
    if (!$ok) {
        bg_return(false, "SQL ผิดพลาด");
    }
    bg_delete_old_upload($old);
    bg_return(true, "ลบรูปพื้นหลังแล้ว");
}

if ($mode === 'overlay') {
    $ok = dd_q("UPDATE setting SET bg_overlay = ?", [$overlay]);
    bg_return((bool) $ok, $ok ? "บันทึกความเข้มแล้ว" : "SQL ผิดพลาด");
}

if ($mode === 'url') {
    $link = trim($_POST['link'] ?? '');
    if ($link === '') {
        bg_return(false, "กรุณาใส่ลิงก์รูปภาพ");
    }
    if (strlen($link) > 500 || !preg_match('#^https?://#i', $link) || !filter_var($link, FILTER_VALIDATE_URL) || preg_match('/["\'()<>\\\\\s]/', $link)) {
        bg_return(false, "ลิงก์รูปภาพไม่ถูกต้อง (ต้องขึ้นต้นด้วย http:// หรือ https:// และห้ามมีช่องว่าง)");
    }
    $ok = dd_q("UPDATE setting SET bg_image = ?, bg_overlay = ?", [$link, $overlay]);
    if (!$ok) {
        bg_return(false, "SQL ผิดพลาด");
    }
    bg_delete_old_upload($old);
    bg_return(true, "เปลี่ยนรูปพื้นหลังสำเร็จ", ['url' => $link]);
}

if ($mode === 'upload') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        bg_return(false, "อัปโหลดไม่สำเร็จ (ไฟล์อาจใหญ่เกินที่เซิร์ฟเวอร์อนุญาต)");
    }
    $f = $_FILES['file'];
    if ($f['size'] > 5 * 1024 * 1024) {
        bg_return(false, "ไฟล์ใหญ่เกิน 5 MB");
    }
    if (!is_uploaded_file($f['tmp_name'])) {
        bg_return(false, "ไฟล์ไม่ถูกต้อง");
    }
    $info = @getimagesize($f['tmp_name']);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', IMAGETYPE_GIF => 'gif'];
    if (!$info || !isset($types[$info[2]])) {
        bg_return(false, "รองรับเฉพาะไฟล์รูป JPG, PNG, WEBP, GIF");
    }
    $dir = dirname(__DIR__, 2) . '/assets/uploads';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        bg_return(false, "สร้างโฟลเดอร์ assets/uploads ไม่ได้");
    }
    $name = 'bg_' . bin2hex(random_bytes(8)) . '.' . $types[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        bg_return(false, "บันทึกไฟล์ไม่สำเร็จ (เช็คสิทธิ์เขียนโฟลเดอร์ assets/uploads)");
    }
    $path = 'assets/uploads/' . $name;
    $ok = dd_q("UPDATE setting SET bg_image = ?, bg_overlay = ?", [$path, $overlay]);
    if (!$ok) {
        @unlink($dir . '/' . $name);
        bg_return(false, "SQL ผิดพลาด");
    }
    bg_delete_old_upload($old);
    bg_return(true, "อัปโหลดและเปลี่ยนรูปพื้นหลังสำเร็จ", ['url' => $path]);
}

bg_return(false, "คำสั่งไม่ถูกต้อง");
